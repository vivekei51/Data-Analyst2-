# Power_Bi_Dashboard
HR_Analytics_End-to-end_Project 
Help an organisation to improve employee performance,
improve employee retention i.e reduce attrition by creating a Power Bi dashboard.
